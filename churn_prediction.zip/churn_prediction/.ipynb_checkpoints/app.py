import pandas as pd 
import streamlit as  st 
import numpy as np
import joblib
import os
import sklearn






st.title('BANK CHURN PREDICTION')

# Creating a form
with st.form("prediction_form"):
    Tenure = st.number_input("Enter Tenure", min_value=0, max_value=50)
    balance = st.number_input("Enter Balance", min_value=0, max_value=1000000, value=0)
    Number_of_products = st.number_input("Enter number of products that customer holds :", min_value=0, max_value = 15 ,value=0)

    HasCrCard = st.selectbox("Enter Customer has a credit card or not", ['Yes' , 'No'])
    IsActiveMember = st.selectbox("Enter customer is a active member ",['Yes' , 'No'])

    EstimatedSalary = st.number_input("Enter customer Estimated salary/ salary", min_value=0, max_value=5000000)
    complain =  st.selectbox("Enter did customer registered a complain ", ['Yes' , 'No'])
    Satisfaction_Score = st.number_input("Enter customer Satisfaction Score , between 1 - 5", min_value=0, max_value=5)
    Point_Earned = st.number_input("Enter Point earned by customer", min_value=0, max_value=1000)

    geography = st.selectbox("Select Geography", ["Spain", "Germany", "France"])
    Gender = st.selectbox("Select Gender of the customer" , ['Male' , "Female"])
    Card_type = st.selectbox("Select a card type of the customer", ['Daimond','Gold', 'Platinum', 'Silver'])


    # Submit button for the form

    submitted = st.form_submit_button("Predict")


if submitted:
    # Initialize variables

    Geography_Spain = 0
    Geography_Germany = 0
    Geography_France = 0
    Gender_Male = 0
    Card_Type_GOLD = 0
    Card_Type_PLATINUM = 0
    Card_Type_SILVER = 0

    # One-hot encode the geography
    if geography == "Spain":
        Geography_Spain = 1
    elif geography == "Germany":
        Geography_Germany = 1
    

    # One-hot encode the gender
    if Gender == "Male":
        Gender_Male = 1

    # One-hot encode the card type
    if Card_type == "Gold":
        Card_Type_GOLD = 1
    elif Card_type == "Platinum":
        Card_Type_PLATINUM = 1
    elif Card_type == "Silver":
        Card_Type_SILVER = 1

    # Convert categorical inputs to binary
    HasCrCard = 1 if HasCrCard == "Yes" else 0
    IsActiveMember = 1 if IsActiveMember == "Yes" else 0
    complain = 1 if complain == "Yes" else 0

    # Now,create the feature vector for prediction
    feature_vector = np.array([[Tenure, balance, Number_of_products, HasCrCard, IsActiveMember, EstimatedSalary, complain,
                                 Satisfaction_Score, Point_Earned,Geography_Germany, Geography_Spain, Gender_Male, 
                                 Card_Type_GOLD, Card_Type_PLATINUM, Card_Type_SILVER]])
    
    st.write("Prediction is in process")


    if os.path.exists('Churn_Prediction_model'):
        model = joblib.load('Churn_Prediction_model')
        prediction = model.predict(feature_vector)

        if prediction[0] == 1:
            st.write("Customer will leave the Bank")
        else:
            st.write("Customer will not leave the Bank")
    else:
        st.write("Model file not found. Please ensure the correct path to the model.")

    





